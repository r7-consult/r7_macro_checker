from fastapi import FastAPI, WebSocket, HTTPException
from pydantic import BaseModel
from asyncio import Queue


class Post(BaseModel):
    macro: str


macroQueue = None
resultQueue = None


app = FastAPI()


@app.post("/check")
async def check(post: Post):

    if macroQueue == None:
        raise HTTPException(status_code=503, detail='Plugin is not connected')

    await macroQueue.put(post.macro)

    result = await resultQueue.get()
    return { 'result': result }



@app.websocket("/ws")
async def websocket_endpoint(websocket: WebSocket):
    global macroQueue, resultQueue

    await websocket.accept()

    macroQueue = Queue();
    resultQueue = Queue();

    while True:
        macro = await macroQueue.get()
        await websocket.send_text(macro)

        result = await websocket.receive_text()
        await resultQueue.put(result)
